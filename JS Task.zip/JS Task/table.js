//Retrieve
//document.getElementById("result").innerHTML = sessionStorage.getItem("email");


var st1 = {firstname:"John", lastname:"Doe", phone:9876543210, age:50, eyeColor:"blue"};


document.getElementById("st1_firstname").innerHTML=st1.firstname;
document.getElementById("st1_lastname").innerHTML=st1.lastname;