function validateForm() {
  var em = document.getElementById("email").value;
  var pwd = document.getElementById("pwd").value;
  if (em == "admin@gmail.com" && pwd == "Admin@123*")
  {
    /*if (typeof (Storage) !== "undefined")
    {
      // Store
      sessionStorage.setItem("email", em);
      
    }
    else 
    {
      alert( "Sorry, your browser does not support Web Storage...")
    }*/
    window.open("table.html")
  }
  else 
  {
    alert("Error Password or Email")/*displays error message*/
  }



}


