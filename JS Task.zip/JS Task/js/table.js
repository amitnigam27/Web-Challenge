//Retrieve



if (sessionStorage.getItem('email') != null)
{
    document.getElementById("result").innerHTML = "Hello " + sessionStorage.getItem("email");
    var st = [{ firstname: "Amit", lastname: "Nigam", phone: 9876543210, age: 20, eyeColor: "black", gender: "Male" },{ firstname: "Rajiv", lastname: "Singh", phone: 9876543210, age: 10, eyeColor: "blue", gender: "Male" }, { firstname: "Ravi", lastname: "Sharma", phone: 9876546410, age: 50, eyeColor: "green", gender: "Male" }];
    var text = "";
    for (let i = 0; i < st.length; i++)
    {
    text += "<tr>";
    text += "<td>" + (st[i].firstname) + "</td>";
    text += "<td>" + (st[i].lastname) + "</td>";
    text += "<td>" + (st[i].phone) + "</td>";
    text += "<td>" + '<a href="#" onclick=fun(' + i + ')>Details</a>' + "</td>";
    text += "</tr>";
    }
    document.getElementById("table").innerHTML = text;
    
}
else
{
    alert("You have not logged in.  Please Log in Again...")
    window.location='index.html'
}






var details = document.getElementById("datail");

function fun(no){
             
                var lo="";
    lo += "<tr>";
    lo += "<td>"+"First Name" +"</td>";
    lo += "<td>" + (st[no].firstname) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Last Name" +"</td>";
    lo += "<td>" + (st[no].lastname) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Mobile" +"</td>";
    lo += "<td>" + (st[no].phone) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Age" +"</td>";
    lo += "<td>" + (st[no].age) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Eye Color" +"</td>";
    lo += "<td>" + (st[no].eyeColor) + "</td>";
    lo += "</tr>";


    lo += "<tr>";
    lo += "<td>"+"Gender" +"</td>";
    lo += "<td>" + (st[no].gender) + "</td>";
    lo += "</tr>";
    document.getElementById("detail").innerHTML =lo;    
            
}

function func()
{sessionStorage.removeItem("email");
    sessionStorage.clear();
}


