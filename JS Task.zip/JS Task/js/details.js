
function fun(no, st)
    {
        var lo="";
    lo += "<tr>";
    lo += "<td>"+"First Name" +"</td>";
    lo += "<td>" + (st[no].firstname) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Last Name" +"</td>";
    lo += "<td>" + (st[no].lastname) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Mobile" +"</td>";
    lo += "<td>" + (st[no].phone) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Age" +"</td>";
    lo += "<td>" + (st[no].age) + "</td>";
    lo += "</tr>";

    lo += "<tr>";
    lo += "<td>"+"Eye Color" +"</td>";
    lo += "<td>" + (st[no].eyeColor) + "</td>";
    lo += "</tr>";


    lo += "<tr>";
    lo += "<td>"+"Gender" +"</td>";
    lo += "<td>" + (st[no].gender) + "</td>";
    lo += "</tr>";
    document.getElementById("detail").innerHTML =lo;    
}
    